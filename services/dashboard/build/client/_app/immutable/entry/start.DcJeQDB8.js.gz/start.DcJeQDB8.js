import{l as o,s as r}from"../chunks/TUcuHu3_.js";export{o as load_css,r as start};
