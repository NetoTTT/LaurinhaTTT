import{l as o,s as r}from"../chunks/BJ0iTM_n.js";export{o as load_css,r as start};
